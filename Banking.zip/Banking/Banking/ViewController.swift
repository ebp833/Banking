//
//  ViewController.swift
//  Banking
//
//  Created by Ethan on 3/22/19.
//  Copyright © 2019 Ethan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var MovementLabel: UITextField!
    @IBOutlet weak var ResetButton: UIButton!
    @IBOutlet weak var CardLabel: UITextField!
    @IBOutlet weak var amount: UITextField!
    @IBOutlet weak var CurrentBalance: UILabel!
    @IBOutlet weak var movement_Type: UISwitch!
    @IBOutlet weak var card_Type: UISwitch!
    @IBOutlet weak var SubmitButton: UIButton!
    @IBOutlet weak var DebitCount: UILabel!
    var amountTOMove:Double=0
    var debituses:Int = 0
    var currentBalance:Double = 0
    let fileName = "Data"
    let DocumentDirURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create:true)
    
    func doStuff(){

        if amount.text!.isEmpty{
            amountTOMove=0.0
            
        }
        else{
            amountTOMove = Double(amount.text!)!
        }
        if !card_Type.isOn{
            if movement_Type.isOn{
                debituses+=1
            }
        }
        
        let fileURL = DocumentDirURL.appendingPathComponent(fileName).appendingPathExtension("txt")
        
        print("File Path: \(fileURL.path)")
        
        
        if !movement_Type.isOn{
            currentBalance += amountTOMove
            
        }
            
        else{
            currentBalance -= amountTOMove
            
        }
        let writeString = "\(String(currentBalance)):\(debituses)"
        do{
            
            try writeString.write(to: fileURL, atomically: true, encoding:  String.Encoding.utf8)
            print("Succesful")
            CurrentBalance.text="$ \(String(currentBalance))"
            DebitCount.text="\(debituses)"
        }
        catch let error as NSError{
            print("Failed to write to URL ")
            print(error)
        }
        amount.text=""
        
        
        
    }
    
    @IBAction func SubmitButtonPress(_ sender: Any) {
        doStuff()
    }
    
    @IBAction func FinishText(_ sender: Any) {
        doStuff()
    }
    @IBAction func reset(_ sender: UIButton) {
        let fileURL = DocumentDirURL.appendingPathComponent(fileName).appendingPathExtension("txt")
        let fileManager = FileManager.default
        do{
            try fileManager.removeItem(atPath: fileURL.path)
            CurrentBalance.text="$ 0"
            currentBalance=0.0
            DebitCount.text="0"
            debituses=0
            amount.text=""
        }
        catch let error as NSError{
            print("Oops! Something went wrong")
            print(error)
        }
        
    }
    
    @objc func card_TypeChanged(card_Type:UISwitch){
        if card_Type.isOn{
            CardLabel.text = "Credit"
        }
        else{
            CardLabel.text="Debit"
        }
    }
    @objc func movementTypeChanged(movement_Type:UISwitch){
        if(movement_Type.isOn){
            MovementLabel.text = "Withdrawl"
        }
        else{
            MovementLabel.text="Deposit"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        card_Type.addTarget(self, action: #selector(card_TypeChanged), for: .valueChanged)
        movement_Type.addTarget(self, action: #selector(movementTypeChanged), for: .valueChanged)
        CardLabel.text="Credit"
        MovementLabel.text="Withdrawl"
        var readString = ""
        let fileURL = DocumentDirURL.appendingPathComponent(fileName).appendingPathExtension("txt")
        do{
            readString=try String(contentsOf: fileURL)
            var strings = readString.components(separatedBy: ":")
            CurrentBalance.text = "$ \(strings[0])"
            debituses = Int(strings[1])!
            DebitCount.text=strings[1]
            currentBalance = Double(strings[0])!
        }
        catch let error as NSError{
            print("Failed to read file")
            print(error)
            CurrentBalance.text = "$ 0"
            currentBalance=0
            debituses=0
        }
  
        
    }
}

